
public class c1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int age = 21 ;
		
		if(age <= 20) {
			
			throw new ArithmeticException("Access denied - You must be at least 20  years old.");
			
		}else {
			
			
			System.out.println("Access granted - You are old enough!");
			
		}
		
		
		
		
		
	}

}
